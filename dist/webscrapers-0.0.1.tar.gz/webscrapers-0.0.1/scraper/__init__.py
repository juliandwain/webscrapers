# -*- coding: utf-8 -*-

__doc__ = """This module implements some scrapers.
"""
