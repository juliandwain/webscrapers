# -*- coding: utf-8 -*-

__doc__ = """This module implements some scrapers.
"""

__version__ = "0.0.2"
